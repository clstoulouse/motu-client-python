from distutils.core import setup
from os.path import splitext, basename
import glob
setup(
  name = 'motu-client',
  version = '1.4.13',
  python_requires='>=2.7, <3',
  description = 'Extract and download gridded data through a python command line from Motu web server. Used in CMEMS context http://marine.copernicus.eu/',
  long_description = 'Motu is a high efficient and robust Web Server which fills the gap between heterogeneous data providers to end users. Motu handles, extracts and transforms oceanographic huge volumes of data without performance collapse. This client enables to extract and download data through a python command line.',
  keywords = ['Copernicus', 'CMEMS', 'CLS', 'Motu', 'motu-client-python', 'Dissemination Unit'],
  
  author = 'Sylvain MARTY, CLS',
  author_email = 'smarty@cls.fr',
  platforms=['any'],
  
  url = 'https://github.com/clstoulouse/motu-client-python',
  license='LGPL',
  
  package_dir = {'': 'src/python'},
  packages=['', 'motuclient'],
  include_package_data = True,
  package_data={'motuclient/cfg': ['src/python/motuclient/cfg/log.ini',
                                    'src/python/motuclient/cfg/messages.properties']},
  data_files=[('motu-client/cfg', [ 'src/python/motuclient/cfg/log.ini',
                        'src/python/motuclient/cfg/messages.properties'])],
  
  download_url = 'https://github.com/clstoulouse/motu-client-python/releases/download/motu-client-python-1.4.00/motu-client-python-1.4.00-20170410143941999-bin.tar.gz', # https://github.com/clstoulouse/motu-client-python/archive/motu-client-python-1.4.00.tar.gz
  
  classifiers = ['Development Status :: 5 - Production/Stable',
                 'Programming Language :: Python :: 2.7',
                 'License :: OSI Approved :: GNU Lesser General Public License v3 (LGPLv3)',
                 'Topic :: Scientific/Engineering :: GIS',
                 'Environment :: Console',
                 'Natural Language :: English',
                 'Operating System :: OS Independent',
          ]
)